var BasicGame ={};
var lata, ai, life;
var restartButton;
var titlepage;
var w=800, h=600;
var a=0,b=3;
var player1, player2, ground, ground1, rock, keyboard, diamond, diamonds, rocks, bestScore, scoreText, debri, debris, gameover, tree, gameStorage, retrieveBest, life, firstaid, firstaids, push, aww,countdown, reStart, baddie;

var game = new Phaser.Game(800,600, Phaser.CANVAS, '');
        BasicGame = function(game){
        };
// var boundWidth=726;
BasicGame.prototype = {
    init: function(){},
 preload: function(){
    game.load.image('bg', 'img/bg.jpg');
    game.load.image('ground', 'img/platform.png');
    game.load.image('gameover', 'img/overgame.jpg');
    game.load.spritesheet('player1', 'img/player1.png',100,100);
    game.load.spritesheet('lata', 'img/tsato.png',100,100);
    game.load.spritesheet('debri', 'img/tsenelas.png',50,50);
    game.load.image('tile', 'img/shoot.png');
    game.load.spritesheet('ai', 'img/ai.png',100,100);

},

 create: function() {
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.setScreenSize = true;

    game.add.image(0,0,'bg');
    ai = game.add.sprite(350,220,'ai');
    lata = game.add.sprite(340,100,'lata');
    tile = game.add.button(600,420,'tile', pushTile);
    // game.world.setBounds(0,0,76,726);
    game.physics.startSystem(Phaser.Physics.ARCADE);
    ground = game.add.sprite(0,0,'ground');
   
    // baddie = game.add.sprite(350,345,'baddie');
    player1 = game.add.sprite(350,550,'player1');
    player1.frame=3;
    // aww = game.add.sprite(player1(w,h),'aww');

    player1.animations.add('down',[0,1,2,3,4],50,true)
    lata.animations.add('tang',[0,1,2,3],20,false)
    ai.animations.add('ai',[0,1],9,true)
    player1.animations.add('player1',[0,2,1,0],14,false)
     
    keyboard = game.input.keyboard.createCursorKeys();
    console.log(game);
    createDebris(3000);
    debri = game.add.group();
    debri.enableBody = true;


    game.physics.arcade.enable(ground);
    ground.scale.x = 2;
    ground.body.immovable = true;
    game.physics.arcade.enable(lata);
    // lata.body.immovable = true;
    game.physics.arcade.enable(ai);
    ai.body.immovable = true;
    ai.body.collideWorldBounds = true;

    ground.body.collideWorldBounds = true;
    game.physics.arcade.enable(player1);
    player1.body.collideWorldBounds = true;


    player1.body.velocity.x=769;
    player1.body.bounce.x=1;
    ai.body.velocity.x=-330;
    ai.body.bounce.x=1;

    life = game.add.text(50,10,'LIFE: 3',{fill:"black"});
    scoreText = game.add.text(650,10,'SCORE: 0',{fill:"black"});
    bestScore = game.add.text(580,40,'BEST SCORE: '+retrieveBest(),{fill:"black"});

    },

// var x = 0;
     update: function() {
        game.physics.arcade.collide(player1,ground);

        game.physics.arcade.overlap(ground,debri,killGround);
        game.physics.arcade.overlap(lata,debri,killLata1);
        game.physics.arcade.overlap(debri,ai,killLata);

            if(keyboard.right.isDown){
            player1.body.velocity.x=270
        }
            else   if(keyboard.up.isDown){
            player1.body.velocity.x=-270
        }
            else{
                ai.animations.play('ai');
            }
        },
        
        createDebris:function (time){
            setInterval(function(){
            },300)
        },
        
        resetGround:function (){
            ground1.reset(200,550);
        },
        killLata1:function(lata,debris){
            debris.kill();
            lata.animations.play('tang');
                a = a + 10;
                scoreText.text = "Score: "+a;
                if(a==30){
                    ai.body.velocity.x=414;
                }
                else if(a==50){
                    ai.body.velocity.x=-528;
                }
                else if(a==70){
                    ai.body.velocity.x=693;
                }
                else if(a==90){
                    ai.body.velocity.x=-827;
                }
                else if(a==100){
                    ai.body.velocity.x=1032;
                }
                else if(a==140){
                    ai.body.velocity.x=-1430;
                }
                },
        killLata:function (ai,debris){
            debris.kill();
            b=b-0.5;
            life.text='Life: '+b;
            if(b==0){
                    goButton = game.add.button(100,197,'gameover',overgame);
                    ai.kill();
                    player1.kill();
                    debris.kill();
                    if(retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
            },
        killGround:function (ground,debris){
                debris.kill();
            b=b-0.5;
            life.text='Life: '+b;
            if(b==0){
                    goButton = game.add.button(100,197,'gameover',overgame);
                    ai.kill();
                    player1.kill();
                    debris.kill();
                    if(retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
               },
        pushTile:function (){
                 debris = debri.create(player1.position.x,player1.position.y-100,"debri");
                 debris.animations.add('play',[0,1,2,3,4],25, true);
                debris.body.velocity.y=-650;
                debris.animations.play('play');
                player1.animations.play('player1');
                lata.frame=0;

        },
        pushRight:function (){
        },

        retrieveBest:function (){
            return ((localStorage.getItem("gameStorage") != null) || (localStorage.getItem("gameStorage") != ""))?localStorage.getItem("gameStorage"):0;
        },
        overgame:function (){
            window.location.href=window.location.href;
        }
};
game.state.add('Play', BasicGame, true);
